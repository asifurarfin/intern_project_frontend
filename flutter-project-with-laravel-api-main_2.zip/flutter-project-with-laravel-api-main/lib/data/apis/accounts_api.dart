var loginApi ='http://10.0.2.2:8000/api/login';
var userRegister = 'http://10.0.2.2:8000/api/user/register';
var managerRegister = 'http://10.0.2.2:8000/api/manager/register';
var itdeskRegister = 'http://10.0.2.2:8000/api/itdesk/register';
var logoutApi = "http://10.0.2.2:8000/api/user/logout";