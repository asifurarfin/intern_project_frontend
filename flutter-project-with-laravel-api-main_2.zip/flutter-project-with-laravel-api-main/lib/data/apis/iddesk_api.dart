var createCategoryApi = "http://10.0.2.2:8000/api/category/create";
var createSubCategoryApi = "http://10.0.2.2:8000/api/subcategory/create";
var getCategoryLists = "http://10.0.2.2:8000/api/category/list";


var getUserListAndTikets = "http://10.0.2.2:8000/api/user/list";
