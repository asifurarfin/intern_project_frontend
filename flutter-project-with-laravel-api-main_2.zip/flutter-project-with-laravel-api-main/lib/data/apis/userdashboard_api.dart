var categoryApi = 'http://10.0.2.2:8000/api/category/list';
var getTicketApi = 'http://10.0.2.2:8000/api/ticket/list';
var createTicketApi = 'http://10.0.2.2:8000/api/ticket/create';
