import 'package:flutter/material.dart';

const primaryColor = Color(0xff687CD3);
const textDarkColor = Color(0xff161C2B);
const textLightColor = Color(0xffC4D1E8);
const deposit = Color(0xff27B887);
const withdraw = Color(0xffF66E65);
const bgcolor = Color(0xffF1F1F1);
